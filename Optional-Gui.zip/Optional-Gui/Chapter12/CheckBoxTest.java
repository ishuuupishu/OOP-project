import javax.swing.JFrame;

public class CheckBoxTest 
{
    public static void main(String[] args) {
        CheckboxFrame checkboxFrame = new CheckboxFrame();
        checkboxFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        checkboxFrame.setSize(675,150);
        checkboxFrame.setVisible(true);
    }
}
