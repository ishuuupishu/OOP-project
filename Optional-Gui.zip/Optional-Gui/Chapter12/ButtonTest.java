// Fig. 12.16
import javax.swing.JFrame;

public class ButtonTest 
{
    public static void main(String[] args) {
        ButtonFrame buttonFrame = new ButtonFrame();
        buttonFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        buttonFrame.setSize(600,350);
        buttonFrame.setVisible(true);
    }    
}
